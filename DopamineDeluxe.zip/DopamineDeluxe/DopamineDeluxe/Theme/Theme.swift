import SwiftUI

/// Central palette for Dopamine Deluxe: black and deep violet with electric purple glow.
enum Theme {
    static let bgTop = Color(red: 0.07, green: 0.01, blue: 0.13)
    static let bgBottom = Color.black

    static let violet = Color(red: 0.42, green: 0.13, blue: 0.86)
    static let purple = Color(red: 0.62, green: 0.25, blue: 1.00)
    static let magenta = Color(red: 0.86, green: 0.32, blue: 1.00)
    static let lavender = Color(red: 0.80, green: 0.68, blue: 1.00)
    static let mint = Color(red: 0.55, green: 1.00, blue: 0.82)

    static let accent = LinearGradient(
        colors: [magenta, purple, violet],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
    )

    static let background = LinearGradient(
        colors: [bgTop, bgBottom],
        startPoint: .top,
        endPoint: .bottom
    )
}

import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var state: AppState
    @State private var confirmReset = false

    private var appVersion: String {
        Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0"
    }
    private var buildNumber: String {
        Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "1"
    }

    var body: some View {
        ZStack {
            AnimatedBackground()
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    Text("Settings")
                        .font(.system(size: 34, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white)

                    SettingsGroup(title: "Simulation") {
                        ToggleRow(icon: "hare.fill", title: "Fast mode",
                                  subtitle: "Plays the animation in about 4 seconds",
                                  isOn: $state.fastMode)
                        rowDivider
                        ToggleRow(icon: "terminal.fill", title: "Show log",
                                  subtitle: "Display the simulated log while running",
                                  isOn: $state.showLog)
                        rowDivider
                        ToggleRow(icon: "iphone.radiowaves.left.and.right", title: "Haptics",
                                  subtitle: "Vibration feedback during the animation",
                                  isOn: $state.hapticsEnabled)
                    }

                    SettingsGroup(title: "iOS Version") {
                        ToggleRow(icon: "apple.logo", title: "Show simulated version",
                                  subtitle: "Display a version of your choice instead of the detected one",
                                  isOn: $state.useSimulatedVersion)
                        if state.useSimulatedVersion {
                            rowDivider
                            HStack {
                                IconChip(systemName: "number")
                                Text("Version").font(.body.weight(.semibold))
                                Spacer()
                                Menu {
                                    Picker("Version", selection: $state.simulatedVersion) {
                                        ForEach(AppState.versionChoices, id: \.self) { v in
                                            Text("iOS \(v)").tag(v)
                                        }
                                    }
                                } label: {
                                    HStack(spacing: 6) {
                                        Text("iOS \(state.simulatedVersion)")
                                        Image(systemName: "chevron.up.chevron.down").font(.caption)
                                    }
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(Theme.lavender)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 8)
                                    .background(Capsule().fill(Theme.purple.opacity(0.22)))
                                }
                            }
                            .padding(.vertical, 6)
                        }
                    }

                    SettingsGroup(title: "Appearance") {
                        ToggleRow(icon: "sparkles", title: "Reduce glow animation",
                                  subtitle: "Freezes the animated background",
                                  isOn: $state.reducedGlow)
                    }

                    SettingsGroup(title: "Data") {
                        Button {
                            confirmReset = true
                        } label: {
                            HStack {
                                IconChip(systemName: "arrow.counterclockwise")
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Reset simulation").font(.body.weight(.semibold))
                                    Text("Sets status back to Not Jailbroken")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                Spacer()
                            }
                            .foregroundStyle(.white)
                            .padding(.vertical, 6)
                        }
                        .buttonStyle(PressScaleStyle())
                    }

                    SettingsGroup(title: "About") {
                        infoRow("Version", "\(appVersion) (\(buildNumber))")
                        rowDivider
                        infoRow("Type", "Visual simulator")
                        rowDivider
                        infoRow("System access", "None")
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 32)
            }
            .scrollIndicators(.hidden)
        }
        .confirmationDialog("Reset simulation?", isPresented: $confirmReset, titleVisibility: .visible) {
            Button("Reset", role: .destructive) { state.reset() }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("Nothing on your device changes. Only the simulated status resets.")
        }
    }

    private var rowDivider: some View {
        Divider().overlay(Color.white.opacity(0.08))
    }

    private func infoRow(_ title: String, _ value: String) -> some View {
        HStack {
            Text(title).foregroundStyle(.secondary)
            Spacer()
            Text(value).fontWeight(.semibold).foregroundStyle(.white)
        }
        .font(.subheadline)
        .padding(.vertical, 6)
    }
}

struct SettingsGroup<Content: View>: View {
    let title: String
    @ViewBuilder var content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(.footnote.weight(.semibold))
                .foregroundStyle(Theme.lavender)
                .padding(.leading, 6)
            VStack(spacing: 6) { content }
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .frame(maxWidth: .infinity)
                .glass(cornerRadius: 22)
        }
    }
}

struct IconChip: View {
    let systemName: String

    var body: some View {
        Image(systemName: systemName)
            .font(.subheadline.weight(.semibold))
            .foregroundStyle(.white)
            .frame(width: 32, height: 32)
            .background(RoundedRectangle(cornerRadius: 9, style: .continuous).fill(Theme.accent))
    }
}

struct ToggleRow: View {
    let icon: String
    let title: String
    let subtitle: String
    @Binding var isOn: Bool

    var body: some View {
        HStack(spacing: 14) {
            IconChip(systemName: icon)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(.body.weight(.semibold)).foregroundStyle(.white)
                Text(subtitle).font(.caption).foregroundStyle(.secondary)
            }
            Spacer(minLength: 8)
            Toggle("", isOn: $isOn)
                .labelsHidden()
                .tint(Theme.purple)
                .accessibilityLabel(title)
        }
        .padding(.vertical, 6)
    }
}

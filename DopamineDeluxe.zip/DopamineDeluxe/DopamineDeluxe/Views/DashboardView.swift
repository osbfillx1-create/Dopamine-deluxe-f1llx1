import SwiftUI

struct DashboardView: View {
    @EnvironmentObject private var state: AppState
    private let device = DeviceInfo.current

    var body: some View {
        ZStack {
            AnimatedBackground()
            ScrollView {
                VStack(spacing: 18) {
                    header
                    StatusCard()
                    infoGrid
                    JailbreakPanel()
                    DisclaimerBanner()
                }
                .padding(.horizontal, 20)
                .padding(.top, 12)
                .padding(.bottom, 32)
            }
            .scrollIndicators(.hidden)
        }
        .fullScreenCover(isPresented: $state.showSuccess) {
            SuccessView().environmentObject(state)
        }
    }

    private var header: some View {
        HStack(spacing: 14) {
            LogoView(size: 64)
            VStack(alignment: .leading, spacing: 2) {
                Text("Dopamine Deluxe")
                    .font(.system(size: 26, weight: .heavy, design: .rounded))
                    .foregroundStyle(Theme.accent)
                Text("Jailbreak simulator")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
    }

    private var infoGrid: some View {
        LazyVGrid(columns: [GridItem(.flexible(), spacing: 14), GridItem(.flexible(), spacing: 14)], spacing: 14) {
            InfoTile(icon: "iphone", title: "Device", value: device.marketingName,
                     note: device.isSimulator ? "\(device.identifier) · Xcode Simulator" : device.identifier)
            InfoTile(icon: "apple.logo", title: "iOS Version", value: "iOS \(state.displayVersion)",
                     note: state.useSimulatedVersion ? "Simulated value" : "Detected on this device")
            InfoTile(icon: "cpu", title: "Chip", value: device.chip, note: nil)
            InfoTile(icon: "checkmark.shield", title: "Real iOS", value: DeviceInfo.detectedSystemVersion,
                     note: "Detected, never modified")
        }
    }
}

struct InfoTile: View {
    let icon: String
    let title: String
    let value: String
    let note: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Image(systemName: icon).foregroundStyle(Theme.accent)
                Text(title).font(.caption.weight(.semibold)).foregroundStyle(.secondary)
            }
            Text(value)
                .font(.title3.weight(.bold))
                .foregroundStyle(.white)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
            if let note {
                Text(note)
                    .font(.caption2)
                    .foregroundStyle(Theme.lavender)
                    .lineLimit(2)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .glass(cornerRadius: 20)
    }
}

struct StatusCard: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        let on = state.isJailbroken
        HStack(spacing: 16) {
            ZStack {
                Circle()
                    .fill((on ? Theme.purple : Color.gray).opacity(on ? 0.55 : 0.15))
                    .blur(radius: 14)
                    .frame(width: 68, height: 68)
                Circle()
                    .strokeBorder(
                        LinearGradient(
                            colors: on
                                ? [Theme.magenta, Theme.violet]
                                : [Color.gray.opacity(0.7), Color.gray.opacity(0.25)],
                            startPoint: .top,
                            endPoint: .bottom
                        ),
                        lineWidth: 3
                    )
                    .frame(width: 60, height: 60)
                Image(systemName: on ? "lock.open.fill" : "lock.fill")
                    .font(.title2.weight(.semibold))
                    .foregroundStyle(on ? Color.white : Color.gray)
                    .contentTransition(.symbolEffect(.replace))
            }

            VStack(alignment: .leading, spacing: 6) {
                Text(on ? "Jailbroken" : "Not Jailbroken")
                    .font(.title2.weight(.bold))
                    .foregroundStyle(.white)
                SimulatedBadge(text: "SIMULATED STATUS")
            }
            Spacer()
        }
        .padding(18)
        .glass(glow: on ? Theme.magenta : Theme.violet)
        .animation(.spring(response: 0.5, dampingFraction: 0.8), value: on)
        .accessibilityElement(children: .combine)
        .accessibilityLabel(on ? "Simulated status: Jailbroken" : "Simulated status: Not jailbroken")
    }
}

struct DisclaimerBanner: View {
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: "info.circle.fill").foregroundStyle(Theme.lavender)
            Text("Dopamine Deluxe is a visual simulator. It does not exploit iOS, modify your device or install anything. Every result shown is simulated.")
                .font(.footnote)
                .foregroundStyle(.secondary)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .glass(cornerRadius: 18, glow: Theme.violet)
    }
}

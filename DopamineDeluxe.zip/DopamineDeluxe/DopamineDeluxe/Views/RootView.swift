import SwiftUI

struct RootView: View {
    @State private var showSplash = true

    var body: some View {
        ZStack {
            TabView {
                DashboardView()
                    .toolbarBackground(.ultraThinMaterial, for: .tabBar)
                    .tabItem { Label("Jailbreak", systemImage: "bolt.fill") }

                SettingsView()
                    .toolbarBackground(.ultraThinMaterial, for: .tabBar)
                    .tabItem { Label("Settings", systemImage: "gearshape.fill") }

                CreditsView()
                    .toolbarBackground(.ultraThinMaterial, for: .tabBar)
                    .tabItem { Label("Credits", systemImage: "sparkles") }
            }
            .tint(Theme.purple)

            if showSplash {
                SplashView()
                    .transition(.opacity)
                    .zIndex(1)
            }
        }
        .task {
            try? await Task.sleep(nanoseconds: 1_600_000_000)
            withAnimation(.easeInOut(duration: 0.6)) { showSplash = false }
        }
    }
}

struct SplashView: View {
    @State private var appear = false

    var body: some View {
        ZStack {
            Theme.background.ignoresSafeArea()
            VStack(spacing: 22) {
                LogoView(size: 150)
                VStack(spacing: 6) {
                    Text("Dopamine Deluxe")
                        .font(.system(size: 32, weight: .heavy, design: .rounded))
                        .foregroundStyle(Theme.accent)
                    Text("Jailbreak simulator")
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(Theme.lavender)
                }
            }
            .scaleEffect(appear ? 1 : 0.85)
            .opacity(appear ? 1 : 0)
        }
        .onAppear {
            withAnimation(.spring(response: 0.8, dampingFraction: 0.7)) { appear = true }
        }
    }
}

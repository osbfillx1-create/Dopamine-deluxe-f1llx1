import SwiftUI

struct JailbreakPanel: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        VStack(spacing: 18) {
            if state.isRunning {
                runningContent
                    .transition(.opacity.combined(with: .scale(scale: 0.96)))
            } else {
                idleContent
                    .transition(.opacity.combined(with: .scale(scale: 0.96)))
            }
        }
        .padding(20)
        .frame(maxWidth: .infinity)
        .glass()
        .animation(.spring(response: 0.5, dampingFraction: 0.85), value: state.isRunning)
    }

    private var runningContent: some View {
        VStack(spacing: 18) {
            ProgressRing(progress: state.progress)
                .frame(width: 190, height: 190)
                .padding(.top, 4)

            Text(state.stageTitle)
                .font(.headline)
                .foregroundStyle(.white)
                .multilineTextAlignment(.center)
                .contentTransition(.opacity)
                .animation(.easeInOut(duration: 0.25), value: state.stageTitle)

            GeometryReader { g in
                ZStack(alignment: .leading) {
                    Capsule().fill(Color.white.opacity(0.08))
                    Capsule()
                        .fill(Theme.accent)
                        .frame(width: max(8, g.size.width * state.progress))
                        .shadow(color: Theme.purple.opacity(0.9), radius: 8)
                }
            }
            .frame(height: 8)

            if state.showLog {
                LogConsole()
            }

            Button(role: .cancel) {
                state.cancel()
            } label: {
                Text("Cancel simulation")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(Theme.lavender)
                    .padding(.vertical, 8)
            }
        }
    }

    private var idleContent: some View {
        VStack(spacing: 14) {
            if state.isJailbroken {
                Text("The simulation has already run. Nothing on this device was changed.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)

                GlowButton(title: "Run Simulation Again", subtitle: "SIMULATED", icon: "arrow.triangle.2.circlepath") {
                    state.startJailbreak()
                }

                Button {
                    withAnimation { state.reset() }
                } label: {
                    Text("Reset to Not Jailbroken")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(Theme.lavender)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 14)
                        .background(Capsule().strokeBorder(Theme.purple.opacity(0.6), lineWidth: 1))
                }
                .buttonStyle(PressScaleStyle())
            } else {
                Text("Tap to play a fake jailbreak. It is an animation only.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)

                GlowButton(title: "Jailbreak", subtitle: "SIMULATED · NO REAL EXPLOIT", icon: "bolt.fill") {
                    state.startJailbreak()
                }
            }
        }
    }
}

struct GlowButton: View {
    let title: String
    let subtitle: String
    let icon: String
    let action: () -> Void

    @State private var pulse = false

    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                Image(systemName: icon)
                    .font(.title2.weight(.bold))
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.title3.weight(.bold))
                    Text(subtitle)
                        .font(.caption2.weight(.heavy))
                        .tracking(1)
                        .opacity(0.8)
                }
                Spacer()
            }
            .foregroundStyle(.white)
            .padding(.vertical, 18)
            .padding(.horizontal, 22)
            .background(
                RoundedRectangle(cornerRadius: 22, style: .continuous).fill(Theme.accent)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .strokeBorder(Color.white.opacity(0.35), lineWidth: 1)
            )
            .shadow(color: Theme.purple.opacity(pulse ? 0.95 : 0.45), radius: pulse ? 28 : 12, y: 6)
        }
        .buttonStyle(PressScaleStyle())
        .onAppear {
            withAnimation(.easeInOut(duration: 1.6).repeatForever(autoreverses: true)) { pulse = true }
        }
    }
}

struct LogConsole: View {
    @EnvironmentObject private var state: AppState

    var body: some View {
        ScrollViewReader { proxy in
            ScrollView {
                VStack(alignment: .leading, spacing: 4) {
                    ForEach(state.log) { line in
                        Text(line.text)
                            .font(.system(size: 11, design: .monospaced))
                            .foregroundStyle(line.kind == .ok ? Theme.mint : Theme.lavender)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .id(line.id)
                    }
                }
                .padding(12)
            }
            .frame(height: 120)
            .background(
                RoundedRectangle(cornerRadius: 14, style: .continuous).fill(Color.black.opacity(0.4))
            )
            .onChange(of: state.log.count) { _, _ in
                if let last = state.log.last {
                    withAnimation { proxy.scrollTo(last.id, anchor: .bottom) }
                }
            }
        }
    }
}

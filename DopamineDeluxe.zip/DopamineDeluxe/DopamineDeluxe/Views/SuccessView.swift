import SwiftUI

struct SuccessView: View {
    @EnvironmentObject private var state: AppState
    @Environment(\.dismiss) private var dismiss
    @State private var appear = false
    @State private var rippling = false
    private let device = DeviceInfo.current

    var body: some View {
        ZStack {
            AnimatedBackground()
            SparkleField().ignoresSafeArea()

            VStack(spacing: 22) {
                Spacer(minLength: 12)

                ZStack {
                    ForEach(0..<3) { i in
                        Circle()
                            .stroke(Theme.purple.opacity(0.7), lineWidth: 2)
                            .frame(width: 140, height: 140)
                            .scaleEffect(rippling ? 2.4 : 0.8)
                            .opacity(rippling ? 0 : 0.7)
                            .animation(
                                .easeOut(duration: 2.4).repeatForever(autoreverses: false).delay(Double(i) * 0.8),
                                value: rippling
                            )
                    }
                    Circle()
                        .fill(Theme.accent)
                        .frame(width: 128, height: 128)
                        .shadow(color: Theme.purple, radius: 30)
                    Image(systemName: "checkmark")
                        .font(.system(size: 56, weight: .bold))
                        .foregroundStyle(.white)
                        .symbolEffect(.bounce, value: appear)
                }
                .scaleEffect(appear ? 1 : 0.3)
                .opacity(appear ? 1 : 0)

                VStack(spacing: 10) {
                    Text("Jailbreak Complete")
                        .font(.system(size: 34, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white)
                    SimulatedBadge(text: "SIMULATED RESULT")
                    Text("This was an animation. Nothing on this device was exploited or modified.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 12)
                }
                .opacity(appear ? 1 : 0)
                .offset(y: appear ? 0 : 20)

                VStack(spacing: 12) {
                    summaryRow("Device", device.marketingName)
                    summaryRow("iOS", "\(state.displayVersion)\(state.useSimulatedVersion ? " (simulated)" : "")")
                    summaryRow("Stages played", "\(state.lastRunStages)")
                    summaryRow("Real changes made", "None")
                }
                .padding(18)
                .glass()
                .opacity(appear ? 1 : 0)

                Spacer()

                Button {
                    dismiss()
                } label: {
                    Text("Done")
                        .font(.headline)
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(RoundedRectangle(cornerRadius: 20, style: .continuous).fill(Theme.accent))
                        .shadow(color: Theme.purple.opacity(0.7), radius: 16, y: 4)
                }
                .buttonStyle(PressScaleStyle())
            }
            .padding(24)
        }
        .onAppear {
            withAnimation(.spring(response: 0.7, dampingFraction: 0.6)) { appear = true }
            rippling = true
        }
    }

    private func summaryRow(_ title: String, _ value: String) -> some View {
        HStack {
            Text(title).foregroundStyle(.secondary)
            Spacer()
            Text(value).fontWeight(.semibold).foregroundStyle(.white)
        }
        .font(.subheadline)
    }
}

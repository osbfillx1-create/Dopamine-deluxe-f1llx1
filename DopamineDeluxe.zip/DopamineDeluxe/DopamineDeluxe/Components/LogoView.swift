import SwiftUI

/// The Dopamine Deluxe mark: a glowing "D" tile inside a rotating neon ring.
struct LogoView: View {
    var size: CGFloat = 96
    @State private var spin = false
    @State private var pulse = false

    var body: some View {
        ZStack {
            Circle()
                .fill(Theme.purple.opacity(0.45))
                .blur(radius: size * 0.28)
                .scaleEffect(pulse ? 1.12 : 0.88)

            Circle()
                .strokeBorder(
                    AngularGradient(
                        colors: [Theme.magenta, Theme.violet, Color.clear, Theme.magenta],
                        center: .center
                    ),
                    lineWidth: size * 0.045
                )
                .rotationEffect(.degrees(spin ? 360 : 0))

            RoundedRectangle(cornerRadius: size * 0.24, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [Color(red: 0.14, green: 0.04, blue: 0.26), Color.black],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                )
                .frame(width: size * 0.72, height: size * 0.72)
                .overlay(
                    RoundedRectangle(cornerRadius: size * 0.24, style: .continuous)
                        .strokeBorder(Theme.purple.opacity(0.7), lineWidth: 1)
                )

            Text("D")
                .font(.system(size: size * 0.46, weight: .black, design: .rounded))
                .foregroundStyle(Theme.accent)
                .shadow(color: Theme.purple.opacity(0.9), radius: size * 0.08)
        }
        .frame(width: size, height: size)
        .onAppear {
            withAnimation(.linear(duration: 9).repeatForever(autoreverses: false)) { spin = true }
            withAnimation(.easeInOut(duration: 2.4).repeatForever(autoreverses: true)) { pulse = true }
        }
        .accessibilityLabel("Dopamine Deluxe logo")
    }
}

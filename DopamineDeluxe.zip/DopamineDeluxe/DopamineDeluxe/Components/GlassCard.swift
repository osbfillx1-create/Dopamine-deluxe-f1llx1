import SwiftUI

/// Glassmorphism surface: blurred material, violet tint, bright rim, soft purple glow.
struct GlassCard: ViewModifier {
    var cornerRadius: CGFloat = 24
    var glow: Color = Theme.purple

    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
        content
            .background(
                ZStack {
                    shape.fill(.ultraThinMaterial)
                    shape.fill(
                        LinearGradient(
                            colors: [Theme.purple.opacity(0.20), Color.clear],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                }
            )
            .overlay(
                shape.strokeBorder(
                    LinearGradient(
                        colors: [Color.white.opacity(0.38), Theme.purple.opacity(0.28), Color.white.opacity(0.05)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: 1
                )
            )
            .shadow(color: glow.opacity(0.25), radius: 18, x: 0, y: 8)
    }
}

extension View {
    func glass(cornerRadius: CGFloat = 24, glow: Color = Theme.purple) -> some View {
        modifier(GlassCard(cornerRadius: cornerRadius, glow: glow))
    }
}

struct PressScaleStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.96 : 1)
            .opacity(configuration.isPressed ? 0.9 : 1)
            .animation(.spring(response: 0.25, dampingFraction: 0.7), value: configuration.isPressed)
    }
}

/// Small capsule used to mark anything that is not real.
struct SimulatedBadge: View {
    var text: String = "SIMULATED"

    var body: some View {
        Text(text)
            .font(.caption2.weight(.heavy))
            .tracking(1.2)
            .foregroundStyle(Theme.lavender)
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            .background(Capsule().fill(Theme.purple.opacity(0.22)))
            .overlay(Capsule().strokeBorder(Theme.purple.opacity(0.5), lineWidth: 1))
    }
}

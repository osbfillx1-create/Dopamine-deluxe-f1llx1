import SwiftUI

struct ProgressRing: View {
    var progress: Double
    var lineWidth: CGFloat = 14

    var body: some View {
        ZStack {
            Circle()
                .stroke(Color.white.opacity(0.08), lineWidth: lineWidth)

            Circle()
                .trim(from: 0, to: max(0.001, min(progress, 1)))
                .stroke(
                    AngularGradient(
                        colors: [Theme.violet, Theme.purple, Theme.magenta],
                        center: .center
                    ),
                    style: StrokeStyle(lineWidth: lineWidth, lineCap: .round)
                )
                .rotationEffect(.degrees(-90))
                .shadow(color: Theme.purple.opacity(0.9), radius: 10)

            VStack(spacing: 2) {
                Text("\(Int(progress * 100))%")
                    .font(.system(size: 42, weight: .bold, design: .rounded))
                    .monospacedDigit()
                    .foregroundStyle(.white)
                Text("SIMULATED")
                    .font(.caption2.weight(.heavy))
                    .tracking(1.5)
                    .foregroundStyle(Theme.lavender)
            }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Simulation progress")
        .accessibilityValue("\(Int(progress * 100)) percent")
    }
}

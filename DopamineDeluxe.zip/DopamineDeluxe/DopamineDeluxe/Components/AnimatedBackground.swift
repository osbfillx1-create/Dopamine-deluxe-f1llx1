import SwiftUI

/// Black-to-violet backdrop with slowly drifting purple light blobs.
struct AnimatedBackground: View {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @EnvironmentObject private var state: AppState

    var body: some View {
        let frozen = reduceMotion || state.reducedGlow
        TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: frozen)) { context in
            let t = frozen ? 0 : context.date.timeIntervalSinceReferenceDate
            GeometryReader { geo in
                let w: CGFloat = geo.size.width
                let h: CGFloat = geo.size.height
                let a = CGFloat(sin(t * 0.30)), b = CGFloat(cos(t * 0.24))
                let c = CGFloat(cos(t * 0.22)), d = CGFloat(sin(t * 0.27))
                let e = CGFloat(sin(t * 0.18)), f = CGFloat(cos(t * 0.21))
                ZStack {
                    Theme.background
                    blob(Theme.purple, size: w * 0.95, opacity: 0.50,
                         x: (-0.22 + 0.12 * a) * w,
                         y: (-0.30 + 0.04 * b) * h)
                    blob(Theme.magenta, size: w * 0.70, opacity: 0.30,
                         x: (0.30 + 0.10 * c) * w,
                         y: (0.05 + 0.05 * d) * h)
                    blob(Theme.violet, size: w * 1.10, opacity: 0.42,
                         x: (-0.10 + 0.12 * e) * w,
                         y: (0.42 + 0.04 * f) * h)
                }
                .frame(width: w, height: h)
                .clipped()
            }
        }
        .ignoresSafeArea()
    }

    private func blob(_ color: Color, size: CGFloat, opacity: Double, x: CGFloat, y: CGFloat) -> some View {
        Circle()
            .fill(color.opacity(opacity))
            .frame(width: size, height: size)
            .blur(radius: 80)
            .offset(x: x, y: y)
    }
}

import SwiftUI

/// Drifting purple sparkles drawn with Canvas. Deterministic, no state.
struct SparkleField: View {
    var count: Int = 40
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: reduceMotion)) { context in
            Canvas { gc, size in
                let t: Double = reduceMotion ? 0 : context.date.timeIntervalSinceReferenceDate
                let width = Double(size.width)
                let height = Double(size.height)
                for i in 0..<count {
                    let x: Double = rand(i, 1) * width
                    let speed: Double = 18 + rand(i, 2) * 55
                    let phase: Double = rand(i, 3) * height
                    let span: Double = height + 40
                    let travelled: Double = (t * speed + phase).truncatingRemainder(dividingBy: span)
                    let y: Double = height + 20 - travelled
                    let radius: Double = 1 + rand(i, 4) * 2.6
                    let twinkle: Double = 0.25 + 0.75 * abs(sin(t * (0.6 + rand(i, 5)) + Double(i)))
                    let base: Color = (i % 3 == 0) ? Theme.magenta : Theme.lavender
                    let rect = CGRect(x: x - radius, y: y - radius, width: radius * 2, height: radius * 2)
                    gc.fill(Path(ellipseIn: rect), with: .color(base.opacity(twinkle)))
                }
            }
        }
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }

    private func rand(_ i: Int, _ salt: Double) -> Double {
        let v = sin(Double(i) * 12.9898 + salt * 78.233) * 43758.5453
        return v - floor(v)
    }
}

import SwiftUI

/// Holds all simulator state. Nothing in here touches the system; it only drives visuals.
@MainActor
final class AppState: ObservableObject {
    enum Phase { case idle, running }

    static let versionChoices = ["27.2", "27.1", "27.0", "26.4", "26.0", "18.6", "18.0", "17.6", "17.0"]

    private let defaults = UserDefaults.standard
    private var task: Task<Void, Never>?

    // MARK: Simulation state
    @Published private(set) var phase: Phase = .idle
    @Published private(set) var progress: Double = 0
    @Published private(set) var stageTitle: String = ""
    @Published private(set) var log: [LogLine] = []
    @Published private(set) var lastRunStages: Int = 0
    @Published var showSuccess = false

    // MARK: Persisted values
    @Published var isJailbroken: Bool { didSet { defaults.set(isJailbroken, forKey: "isJailbroken") } }
    @Published var useSimulatedVersion: Bool { didSet { defaults.set(useSimulatedVersion, forKey: "useSimulatedVersion") } }
    @Published var simulatedVersion: String { didSet { defaults.set(simulatedVersion, forKey: "simulatedVersion") } }
    @Published var fastMode: Bool { didSet { defaults.set(fastMode, forKey: "fastMode") } }
    @Published var showLog: Bool { didSet { defaults.set(showLog, forKey: "showLog") } }
    @Published var hapticsEnabled: Bool { didSet { defaults.set(hapticsEnabled, forKey: "hapticsEnabled") } }
    @Published var reducedGlow: Bool { didSet { defaults.set(reducedGlow, forKey: "reducedGlow") } }

    init() {
        let d = UserDefaults.standard
        isJailbroken = d.bool(forKey: "isJailbroken")
        useSimulatedVersion = d.object(forKey: "useSimulatedVersion") as? Bool ?? true
        simulatedVersion = d.string(forKey: "simulatedVersion") ?? "27.2"
        fastMode = d.bool(forKey: "fastMode")
        showLog = d.object(forKey: "showLog") as? Bool ?? true
        hapticsEnabled = d.object(forKey: "hapticsEnabled") as? Bool ?? true
        reducedGlow = d.bool(forKey: "reducedGlow")
    }

    // MARK: Derived
    var displayVersion: String {
        useSimulatedVersion ? simulatedVersion : DeviceInfo.detectedSystemVersion
    }

    var isRunning: Bool { phase == .running }

    // MARK: Actions
    func startJailbreak() {
        guard phase == .idle else { return }
        phase = .running
        progress = 0
        log = []
        stageTitle = JailbreakStage.all.first?.title ?? ""
        if hapticsEnabled { Haptics.impact(.medium) }
        task = Task { [weak self] in
            await self?.run()
        }
    }

    func cancel() {
        task?.cancel()
        task = nil
        phase = .idle
        progress = 0
        stageTitle = ""
        log = []
    }

    func reset() {
        cancel()
        isJailbroken = false
        showSuccess = false
        if hapticsEnabled { Haptics.notify(.warning) }
    }

    // MARK: Simulation engine
    private func run() async {
        let stages = JailbreakStage.all
        let totalWeight = stages.reduce(0) { $0 + $1.weight }
        let totalSeconds = fastMode ? 4.0 : 10.0
        var completed = 0.0

        for stage in stages {
            if Task.isCancelled { return }
            stageTitle = stage.title
            let span = stage.weight / totalWeight
            let stageSeconds = totalSeconds * span
            let steps = max(stage.lines.count, 1)

            for (index, line) in stage.lines.enumerated() {
                log.append(LogLine(text: line, kind: .info))
                let target = completed + span * Double(index + 1) / Double(steps)
                await animateProgress(to: target, seconds: stageSeconds / Double(steps))
                if Task.isCancelled { return }
            }
            log.append(LogLine(text: "[SIM] ✓ \(stage.title)", kind: .ok))
            completed += span
            if hapticsEnabled { Haptics.impact(.light) }
        }

        progress = 1
        lastRunStages = stages.count
        stageTitle = "Simulation complete"
        isJailbroken = true
        phase = .idle
        task = nil
        if hapticsEnabled { Haptics.notify(.success) }
        try? await Task.sleep(nanoseconds: 450_000_000)
        showSuccess = true
    }

    private func animateProgress(to target: Double, seconds: Double) async {
        let start = progress
        let tick: UInt64 = 30_000_000
        let ticks = max(Int(seconds / 0.03), 1)
        for t in 1...ticks {
            if Task.isCancelled { return }
            try? await Task.sleep(nanoseconds: tick)
            progress = start + (target - start) * Double(t) / Double(ticks)
        }
    }
}

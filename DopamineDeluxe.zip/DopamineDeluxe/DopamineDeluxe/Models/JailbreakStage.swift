import Foundation

/// One step of the fake jailbreak sequence. Everything here is invented text.
struct JailbreakStage: Identifiable {
    let id = UUID()
    let title: String
    let lines: [String]
    let weight: Double
}

struct LogLine: Identifiable {
    enum Kind { case info, ok }
    let id = UUID()
    let text: String
    let kind: Kind
}

extension JailbreakStage {
    static let all: [JailbreakStage] = [
        JailbreakStage(
            title: "Preparing simulation",
            lines: [
                "[SIM] Dopamine Deluxe simulator started",
                "[SIM] No system files will be read or changed"
            ],
            weight: 1
        ),
        JailbreakStage(
            title: "Inventing a kernel exploit",
            lines: [
                "[SIM] Pretending to scan for a vulnerability",
                "[SIM] Nothing found because nothing is searched",
                "[SIM] Generating imaginary primitives"
            ],
            weight: 2
        ),
        JailbreakStage(
            title: "Escaping a pretend sandbox",
            lines: [
                "[SIM] Drawing a sandbox on a napkin",
                "[SIM] Walking out the front door"
            ],
            weight: 1.5
        ),
        JailbreakStage(
            title: "Mounting a make-believe rootfs",
            lines: [
                "[SIM] Mounting /dev/imagination at /var/jb",
                "[SIM] Linking 0 real files"
            ],
            weight: 1.5
        ),
        JailbreakStage(
            title: "Loading a fictional tweak engine",
            lines: [
                "[SIM] Warming up fictional tweak loader",
                "[SIM] Registering 0 tweaks"
            ],
            weight: 1.5
        ),
        JailbreakStage(
            title: "Finishing up",
            lines: [
                "[SIM] Polishing the glow",
                "[SIM] Simulation complete"
            ],
            weight: 1
        )
    ]
}

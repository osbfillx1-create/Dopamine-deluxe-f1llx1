import UIKit

/// Read-only information about the device this app is running on.
struct DeviceInfo {
    let identifier: String
    let marketingName: String
    let chip: String
    let isSimulator: Bool

    @MainActor
    static var detectedSystemVersion: String {
        UIDevice.current.systemVersion
    }

    @MainActor
    static var current: DeviceInfo { detect() }

    @MainActor
    private static func detect() -> DeviceInfo {
        var isSim = false
        let id: String
        #if targetEnvironment(simulator)
        isSim = true
        id = ProcessInfo.processInfo.environment["SIMULATOR_MODEL_IDENTIFIER"] ?? "iPhone15,4"
        #else
        var sys = utsname()
        uname(&sys)
        id = withUnsafeBytes(of: &sys.machine) { raw in
            String(decoding: raw.prefix(while: { $0 != 0 }), as: UTF8.self)
        }
        #endif

        if let known = table[id] {
            return DeviceInfo(identifier: id, marketingName: known.0, chip: known.1, isSimulator: isSim)
        }
        return DeviceInfo(
            identifier: id,
            marketingName: UIDevice.current.model,
            chip: "Unknown",
            isSimulator: isSim
        )
    }

    private static let table: [String: (String, String)] = [
        "iPhone14,7": ("iPhone 14", "A15 Bionic"),
        "iPhone14,8": ("iPhone 14 Plus", "A15 Bionic"),
        "iPhone15,2": ("iPhone 14 Pro", "A16 Bionic"),
        "iPhone15,3": ("iPhone 14 Pro Max", "A16 Bionic"),
        "iPhone15,4": ("iPhone 15", "A16 Bionic"),
        "iPhone15,5": ("iPhone 15 Plus", "A16 Bionic"),
        "iPhone16,1": ("iPhone 15 Pro", "A17 Pro"),
        "iPhone16,2": ("iPhone 15 Pro Max", "A17 Pro"),
        "iPhone17,1": ("iPhone 16 Pro", "A18 Pro"),
        "iPhone17,2": ("iPhone 16 Pro Max", "A18 Pro"),
        "iPhone17,3": ("iPhone 16", "A18"),
        "iPhone17,4": ("iPhone 16 Plus", "A18"),
        "iPhone17,5": ("iPhone 16e", "A18")
    ]
}

#!/bin/bash
# Builds an UNSIGNED Dopamine Deluxe.ipa with no Apple Developer account.
# The result must be re-signed (AltStore, Sideloadly, TrollStore, etc.) before it installs on a device.
set -euo pipefail
cd "$(dirname "$0")/.."

SCHEME="DopamineDeluxe"
BUILD_DIR="build"
rm -rf "$BUILD_DIR"

xcodebuild archive \
  -project DopamineDeluxe.xcodeproj \
  -scheme "$SCHEME" \
  -configuration Release \
  -destination "generic/platform=iOS" \
  -archivePath "$BUILD_DIR/$SCHEME.xcarchive" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY=""

APP="$BUILD_DIR/$SCHEME.xcarchive/Products/Applications/$SCHEME.app"
rm -rf "$BUILD_DIR/Payload"
mkdir -p "$BUILD_DIR/Payload"
cp -R "$APP" "$BUILD_DIR/Payload/"
(cd "$BUILD_DIR" && zip -qry "Dopamine Deluxe.ipa" Payload)
echo "Created: $BUILD_DIR/Dopamine Deluxe.ipa (unsigned)"

# Dopamine Deluxe

A purple-and-black **visual jailbreak simulator** for iPhone, inspired by the look of the Dopamine jailbreak.

> **This app does not jailbreak anything.** It contains no exploit code, reads no private data and changes nothing on the device. Every status, progress bar, log line and success screen is a scripted animation, and the UI labels it as SIMULATED.

## Features
- Dashboard: device model (detected), chip, iOS version, simulated status (Jailbroken / Not Jailbroken)
- iOS version display: detected value plus a selectable simulated value (default **iOS 27.2**, always labelled "Simulated")
- Fake jailbreak with a progress ring, stage titles and a `[SIM]` log
- Simulated success screen with ripples and sparkles
- Settings (fast mode, log, haptics, simulated version, reduce glow, reset) and Credits
- Dark purple glassmorphism, animated glow background, custom logo and app icon
- SwiftUI only, no third-party packages, iPhone + portrait only

## Requirements
- Xcode 16 or newer (any Xcode whose SDK you have installed; the project targets iOS 17.0+)
- Swift 5 language mode

## Run it
1. Open `DopamineDeluxe.xcodeproj`.
2. Select the **DopamineDeluxe** target, then **Signing & Capabilities**: choose your Team and change the bundle ID (`com.example.DopamineDeluxe`) to something unique.
3. Pick an iPhone 15 simulator or your device and press **Run** (⌘R).

To target a newer minimum iOS, change **Minimum Deployments** on the project.

## Archive and export an IPA (Xcode)
1. Set the run destination to **Any iOS Device (arm64)**.
2. **Product > Archive**. The Organizer opens when it finishes (Window > Organizer if not).
3. Select the archive, click **Distribute App**, then choose:
   - **Development** or **Ad Hoc**: an IPA for registered devices (needs a paid developer account and registered device UDIDs)
   - **App Store Connect**: upload for TestFlight / App Store
   - **Custom > Debugging**: same as Development
4. Follow the prompts (automatic signing is fine) and choose **Export** to save `Dopamine Deluxe.ipa`.

### Command line
```bash
xcodebuild archive -project DopamineDeluxe.xcodeproj -scheme DopamineDeluxe \
  -configuration Release -destination "generic/platform=iOS" \
  -archivePath build/DopamineDeluxe.xcarchive
xcodebuild -exportArchive -archivePath build/DopamineDeluxe.xcarchive \
  -exportOptionsPlist scripts/ExportOptions.plist -exportPath build/export
```

### Unsigned IPA (no developer account)
`scripts/build_unsigned_ipa.sh` produces `build/Dopamine Deluxe.ipa` without signing. It must be re-signed by a sideloading tool before it will install on a device.

## Project layout
```
DopamineDeluxe.xcodeproj
DopamineDeluxe/
  App/         DopamineDeluxeApp.swift
  Models/      AppState, DeviceInfo, JailbreakStage
  Theme/       Theme (palette)
  Components/  AnimatedBackground, GlassCard, LogoView, ProgressRing, SparkleField, Haptics
  Views/       RootView, DashboardView, JailbreakPanel, SuccessView, SettingsView, CreditsView
  Resources/   Assets.xcassets (AppIcon, AccentColor, LaunchBackground), Info.plist
scripts/       build_unsigned_ipa.sh, ExportOptions.plist
```
